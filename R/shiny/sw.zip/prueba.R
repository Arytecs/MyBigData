
#install.packages("dpylr")
install.packages("/home//ceferra@upvnet.upv.es/Descargas/plyr_1.8.1.tar.gz", repos=NULL, type="source")install.packages("/home//ceferra@upvnet.upv.es/Descargas/plyr_1.8.1.tar.gz", repos=NULL, type="source")
install.packages("ggplot2")
install.packages("/home//ceferra@upvnet.upv.es/Descargas/rjson_0.2.13.tar.gz", repos=NULL, type="source")
install.packages("ggmap")
install.packages("shiny")